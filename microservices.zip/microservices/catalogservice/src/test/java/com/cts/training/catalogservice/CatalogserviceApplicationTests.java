package com.cts.training.catalogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
