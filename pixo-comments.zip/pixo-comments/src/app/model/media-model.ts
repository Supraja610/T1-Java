export class Media{

    id:number;
    title1:String;
description:String;
    tag1:String;
}