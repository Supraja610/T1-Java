package com.pixogram.userservice.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
@Entity
@Table
public class Authorities implements Serializable {
	
	@Override
	public String toString() {
		return "Authorities [username=" + username + ", authority=" + authority + "]";
	}

	public Authorities() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Authorities(String username, String authority) {
		super();
		this.username = username;
		this.authority = authority;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	@Id
	@Column(insertable = true ,name = "username", length=100)
	private String username;
	
	@Id
	@Column(insertable = true ,name = "authority",length=100)
	private String authority;

}
