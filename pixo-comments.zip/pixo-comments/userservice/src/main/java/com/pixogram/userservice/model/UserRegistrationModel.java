package com.pixogram.userservice.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
public class UserRegistrationModel {
	@Override
	public String toString() {
		return "UserRegistrationModel [username=" + username + ", fname=" + fname + ", lname=" + lname + ", uemail="
				+ uemail + ", password=" + password + ", profile=" + profile + "]";
	}
	public UserRegistrationModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserRegistrationModel(String username, String fname, String lname, String uemail, String password,
			String profile) {
		super();
		this.username = username;
		this.fname = fname;
		this.lname = lname;
		this.uemail = uemail;
		this.password = password;
		this.profile = profile;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	private String username;
	private String fname;
	private String lname;
	private String uemail;
	private String password;
	private String profile;
}
