package com.cts.training.mediaservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaDataModel;
import com.cts.training.mediaservice.model.MediaModel;

import com.cts.training.mediaservice.repository.MediaRepository;
import com.cts.training.mediaservice.service.IMediaService;
import com.cts.training.mediaservice.service.StorageService;

@RestController
public class MediaController {

	// dependency
	private Logger logger=LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IMediaService mediaservice;
	@Autowired
	private StorageService storageService;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/media")
	public ResponseEntity<MediaModel> getall(){
		MediaModel medialist=new MediaModel();
		medialist.setMedialist(this.mediaservice.getall());
		
		
		ResponseEntity<MediaModel> response = new ResponseEntity<MediaModel>(medialist, HttpStatus.OK);
		return response;
	}
	@GetMapping("/media/user/{userId}")
	public ResponseEntity<List<MediaDataModel>> getmediaByUserId(@PathVariable Integer userId)
	{
		List<MediaDataModel> media=this.mediaservice.findAllMediaByUserId(userId);
		ResponseEntity<List<MediaDataModel>> response=new ResponseEntity<List<MediaDataModel>>(media,HttpStatus.OK);
		return response;
	}
	@PostMapping(value="/media",consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file) {
		this.storageService.store(file);
		return true;
		
	}
	@PostMapping(value="/mediadata")
	public boolean saveData (@RequestBody MediaDataModel media) {
	
	
	/*MediaData mediamod=new MediaData();
	mediamod.setUserId(media.getUserid());
	mediamod.setTitle(media.getTitle());
	mediamod.setDescription(media.getDescription());
	mediamod.setFile(media.getUrl());
	mediamod.setTags(media.getTags());
	mediamod.setType(media.getType());*/
	this.mediaservice.save(media);
	return true;
	}
	@GetMapping("/medias/{mediaId}")
	public ResponseEntity<MediaData> getById(@PathVariable Integer mediaId){
		MediaData data=new MediaData();
		Media media = new Media();
		Optional<Media> record=this.mediaservice.getWithId(mediaId);
		if(record.isPresent())
		{
			media=record.get();
		}
		
		data.setId(media.getId());
		data.setUserId(media.getUserId());
		data.setTitle(media.getTitle());
		data.setDescription(media.getDescription());
		data.setFile(media.getFileUrl());
		data.setTags(media.getTags());
		data.setType(media.getMimeType());
		ResponseEntity<MediaData> result = new ResponseEntity<MediaData>(data, HttpStatus.OK);
		return result;
		
	}
	@PutMapping("/media")
	public boolean saveData (@RequestBody MediaData user)
			 {
		this.mediaservice.updateuser(user);
		return true;
	}
}












