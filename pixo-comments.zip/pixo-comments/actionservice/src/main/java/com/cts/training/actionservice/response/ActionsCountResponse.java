package com.cts.training.actionservice.response;

import com.cts.training.actionservice.model.CountOfActionsModel;

public class ActionsCountResponse {
	
	public CountOfActionsModel actiondata;
}
