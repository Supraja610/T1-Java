package com.cts.training.actionservice.repository;

import com.cts.training.actionservice.model.CountOfActionsModel;

public interface CustomActionRepository {

	public CountOfActionsModel getLikesAndDislikes(Integer mediaId);
	
}
