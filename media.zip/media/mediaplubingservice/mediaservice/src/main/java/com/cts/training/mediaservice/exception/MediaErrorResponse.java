package com.cts.training.mediaservice.exception;

public class MediaErrorResponse {

}
