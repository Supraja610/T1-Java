package com.cts.training.media.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.media.feignproxy.MediaServiceProxy;
import com.cts.training.media.model.MediaDataModel;

@RestController
public class MediaController {
 
	@Autowired
	private MediaServiceProxy mediaServiceproxy;
	
	Logger logger =LoggerFactory.getLogger(this.getClass());
	
	@PostMapping("/media")
	public void post (@RequestParam("file") MultipartFile file,
			
			@RequestParam("url") String url,
			@RequestParam("title") String title,
			@RequestParam("description") String description,
			@RequestParam("tags") String tags,
			
			@RequestParam("type") String type,
			@RequestParam("userId") String userId
			) {
		logger.info(tags);
		logger.info(description);
		logger.info(title);
		logger.info(userId);
		MediaDataModel model=new MediaDataModel(Integer.parseInt(userId),url,title,description,tags,type);
		this.mediaServiceproxy.saveData(model);
		this.mediaServiceproxy.save(file);
		
	}

		
	@GetMapping("/media/{userId}")
	public ResponseEntity<List<MediaDataModel>> userMedia(@PathVariable Integer userId)
	{
		ResponseEntity<List<MediaDataModel>> response=this.mediaServiceproxy.getmediaByUserId(userId);
		return response;
		
	}
		
		
	}
			
	
	

