import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UploadMediaService {

  baseUrl: string = 'http://localhost:8765/user-service/register';
  URL='http://localhost:8765/media-plumbing/media';
  constructor(private http: HttpClient, public auth : AuthenticationService) { }
  pushFileToStorage(file: File,  username,password,email, profile) : Observable<HttpEvent<{}>>{
    const formdata: FormData = new FormData();
    formdata.append('file', file, profile);
    formdata.append('username',username);
    formdata.append('profile', profile);
    formdata.append('password',password);
    formdata.append('email',email);
    const req = new HttpRequest('POST', `${this.URL}`, formdata);

    return this.http.request(req);
  }
  pushFileToMediaStorage(file: File,url,title,description,tags,type,userId) : Observable<HttpEvent<{}>>{
    const formdata: FormData = new FormData();
    formdata.append('file', file, url);
    formdata.append('url',url);
    formdata.append('title', title);
    formdata.append('description',description);
    formdata.append('tags',tags);
    formdata.append('type',type);
    formdata.append('userId',userId);
    sessionStorage.setItem("sample",userId);
    const req = new HttpRequest('POST', `${this.URL}`, formdata)
    return this.http.request(req);
  }

}
