import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { Observable } from 'rxjs';
import { SearchedUserModelList } from 'src/app/model/SearchedUserModelList.model';
import { UserAuthService } from '../user-auth.service';
import { RetrieveMedia } from 'src/app/model/RetrieveMedia.model';
const API_URL = "http://localhost:8765/user-service/users";
const REG_URL = "http://localhost:8765/user-service/register";

@Injectable({
  providedIn: 'root'
})


export class UserserviceService {
  Url="http://localhost:8765/misc-plumbing/searched-users/"
  Ret_url="http://localhost:8765/media-plumbing/media/"
  constructor(public http : HttpClient,public  userAuthService: UserAuthService) {


   }

  getAllUsers():any{
    return this.http.get(API_URL);
  }

  getUser(id:number):any{
    return this.http.get(API_URL+"/"+id);
  }

  addUser(user:UserRegistrationDetails):any{
    return this.http.post(REG_URL,user);
  }

  delete(id:number){
    this.http.delete(API_URL+"/"+id);
  }

  update(id:number,user:UserRegistrationDetails):any{
    return this.http.put(API_URL+"/"+id,user);
  }
  getSearchResult(searchText:string):Observable<SearchedUserModelList>
  {
    return this.http.get<SearchedUserModelList>(this.Url+searchText+"/myid/"+this.userAuthService.getUserId());
  }
  getAllMedia():Observable<RetrieveMedia[]>
  {
    return this.http.get<RetrieveMedia[]>(this.Ret_url+this.userAuthService.getUserId());
  }
 

}
