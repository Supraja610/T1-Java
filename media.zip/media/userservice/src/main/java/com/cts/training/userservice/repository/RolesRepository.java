package com.cts.training.userservice.repository;

import com.cts.training.userservice.entity.Roles;

public interface RolesRepository {
	public void save(Roles role);
}
