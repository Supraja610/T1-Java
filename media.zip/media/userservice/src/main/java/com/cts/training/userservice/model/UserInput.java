package com.cts.training.userservice.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserInput {
	
	
	
	private String username;
	private String password;
	//private String repassword;
	private String email;
	private String profile;
	
}
