package com.cts.training.followservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowserviceApplication.class, args);
	}

}
