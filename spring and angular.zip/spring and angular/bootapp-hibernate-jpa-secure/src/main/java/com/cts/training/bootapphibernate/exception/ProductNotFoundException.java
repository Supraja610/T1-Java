package com.cts.training.bootapphibernate.exception;

public class ProductNotFoundException extends RuntimeException{
	public ProductNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
